-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.6.17 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para svdb
CREATE DATABASE IF NOT EXISTS `svdb` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci */;
USE `svdb`;

-- Volcando estructura para tabla svdb.candidato
CREATE TABLE IF NOT EXISTS `candidato` (
  `nombre_candidato` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `nombre_votacion` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`nombre_candidato`,`nombre_votacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla svdb.candidato: ~4 rows (aproximadamente)
INSERT INTO `candidato` (`nombre_candidato`, `nombre_votacion`) VALUES
	('Cristian Garcia', 'Presidencia Consejo Estudiantes'),
	('Jose Sanchez', 'Team Lider'),
	('Pedro Lamarca', 'Team Lider'),
	('Roxana Cabilla', 'Presidencia Consejo Estudiantes');

-- Volcando estructura para tabla svdb.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `contrasena` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `rol` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla svdb.usuario: ~6 rows (aproximadamente)
INSERT INTO `usuario` (`nombre`, `apellido`, `email`, `contrasena`, `rol`) VALUES
	('Gianfranco', 'Luca', 'gianiluca@hotmail.com', '2346', 'votante'),
	('Lucas', 'Cinquerrui', 'lucasc@gmail.com', 'lucas', 'votante'),
	('Manuel', 'Garcia', 'mgarcia@gmail.com', '1234', 'votante'),
	('Mateo Lucas', 'Maza', 'mlm@hotmail.com', '4567', 'votante'),
	('admin', 'admin', 'nicogarcia123@gmail.com', '1111', 'administador'),
	('Paula', 'Garcia', 'pgarcia@gmail.com', '1234', 'votante');

-- Volcando estructura para tabla svdb.votacion
CREATE TABLE IF NOT EXISTS `votacion` (
  `nombre_votacion` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_Inicio` datetime NOT NULL,
  `fecha_fin` datetime NOT NULL,
  `estado` varchar(2) COLLATE utf8_spanish_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`nombre_votacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla svdb.votacion: ~2 rows (aproximadamente)
INSERT INTO `votacion` (`nombre_votacion`, `fecha_Inicio`, `fecha_fin`, `estado`) VALUES
	('Presidencia Consejo Estudiantes', '2024-10-15 00:02:38', '2024-12-15 00:02:50', 'AB'),
	('Team Lider', '2024-11-15 00:03:19', '2024-12-15 00:03:19', 'AB');

-- Volcando estructura para tabla svdb.voto
CREATE TABLE IF NOT EXISTS `voto` (
  `email` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nombre_candidato` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `nombre_votacion` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_voto` datetime NOT NULL,
  PRIMARY KEY (`email`,`nombre_votacion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla svdb.voto: ~5 rows (aproximadamente)
INSERT INTO `voto` (`email`, `nombre_candidato`, `nombre_votacion`, `fecha_voto`) VALUES
	('jgarcia@gmail.com', 'Pedro Lamarca', 'Team Lider', '2024-11-17 00:00:00'),
	('lucasc@gmail.com', 'Cristian Garcia', 'Presidencia Consejo Estudiantes', '2024-11-17 00:00:00'),
	('lucasc@gmail.com', 'Pedro Lamarca', 'Team Lider', '2024-11-17 00:00:00'),
	('mgarcia@gmail.com', 'Pedro Lamarca', 'Team Lider', '2024-11-17 00:00:00'),
	('pgarcia@gmail.com', 'Jose Sanchez', 'Team Lider', '2024-11-17 00:00:00');

-- Volcando estructura para procedimiento svdb.Resultado
DELIMITER //
CREATE PROCEDURE `Resultado`()
SELECT nombre_votacion, nombre_candidato,
          COUNT(*) AS votos
FROM voto 
GROUP BY nombre_votacion, nombre_candidato
ORDER BY COUNT(*) desc//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
